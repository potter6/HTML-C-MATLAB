var gaocheng; //设计高程
var n; //横断面段数
var fangwei = []; //纵断面方位角和横断面方位角
var licheng = []; //纵断面长度（里程）
var K = []; //关键点
// var M = []; //横断面中心点
var point1 = []; //所有散点s
var ZDM = []; //纵断面的点
var HDM1 = []; //单个横断面内的点
var HDM = []; //多个横断面内插点信息

//================纵断面算法================//
function ZongCrossSection(data) {
    gaocheng = document.getElementById('DesignHeight').value;
    for (var i = 0; i < data.length; i++) {
        // p.X = data.x;
        // p.Y = data.y;
        // p.Z = data.z;
        point1.push({ X: data.x, Y: data.y, Z: data.z });
        for (var j = 0; j < dian.Length; j++) {
            if (point1[i].pointName == dian[j]) //寻找关键点并存储
            {
                K[j] = new Point1();
                K[j].pointName = point1[i].pointName;
                K[j].X = point1[i].X;
                K[j].Y = point1[i].Y;
                K[j].Z = point1[i].Z;
            }
        }
    }
    for (var i = 0; i < n; i++) //关键点里程
    {
        //计算纵断面的长度
        fangwei[i] = Calculate.fangwei(K[i], K[i + 1]);
        K[i + 1].licheng = K[i].licheng + Calculate.Distance(K[i], K[i + 1]);
        licheng[i] = K[i + 1].licheng;
        //计算内插点的平面坐标
        while (true) {
            k = k + 10; //纵断面内插间距为10米
            if (k < licheng[i]) //如果内插的下个10米处的点 要比 里程小 
            {
                var p1 = new Point1();
                p1.pointName = "V-" + (k / 10);
                p1.licheng = k;
                p1.X = K[i].X + (p1.licheng - k) * Math.Cos(fangwei[i]);
                p1.Y = K[i].Y + (p1.licheng - k) * Math.Sin(fangwei[i]);
                ZDM.Add(p1);
            } else {
                k = k - 10; //否则减回去
                break;
            }
        }
    }
    var d; //定义一个d 来存储ZDM的某个点和 所有散点间的距离
    var dianhao = 0; //用来存储点号的索引
    for (var i = 0; i < ZDM.Count; i++) //对每个内插点都进行计算
    {
        var dmin1 = 0;
        var HD = 0,
            LD = 0; //计算插值点高程
        for (var q = 0; q < 5; q++) //寻找最近的5个点 最近->次最近->XXXXX->五个中最远
        {
            let dmin = 1000000000000;
            for (var j = 0; j < point1.Count; j++) //遍历所有散点 循环直到找到dmin=d
            {
                d = Calculate.Distance(ZDM[i], point1[j]);
                if (dmin > d && d > dmin1) {
                    dmin = d;
                    dianhao = j;
                }
            }
            dmin1 = dmin; //用中间值记录这个dmin最小的d 到下次循环用上比较 找次最小
            //MessageBox.Show(dmin.ToString());
            HD = HD + point1[dianhao].Z / dmin;
            LD = LD + 1 / dmin;
        }
        ZDM[i].Z = HD / LD;
    }
    //从尾至头把K[i]插入ZDM
    ZDM.Add(K[n]);
    for (var i = n - 1; i > 0; i--) {
        for (var j = ZDM.Count - 1; j > 0; j--) {
            if (K[i].licheng > ZDM[j].licheng) {
                ZDM.Insert(j + 1, K[i]);
                break;
            }
        }
    }
    ZDM.Insert(0, K[0]);
    //MessageBox.Show(ZDM.Count.ToString());
    var S = 0;
    for (var i = 0; i < ZDM.Count - 1; i++) {
        S += ((ZDM[i].Z + ZDM[i + 1].Z - 2 * gaocheng) * 10 / 2);
    }

}

//================横断面算法================//
function hengCrossSection(data) {
    for (var i = 0; i < n; i++) {
        M[i] = new Point1();
        M[i].pointName = "M " + (i + 1);
        M[i].licheng = 25;
        M[i].X = (K[i].X + K[i + 1].X) / 2;
        M[i].Y = (K[i].Y + K[i + 1].Y) / 2;

        fangwei[i] = fangwei[i] - Math.PI / 2;
        //加或者减pi/2都可以，正向和反向的排列，只影响横断面里点的排列往返
    }
    for (var i = 0; i < n; i++) {
        var k = 0;
        for (var j = -25; j <= 25; j = j + 5) //延伸25米
        {
            if (j != 0) {
                var p = new Point1();
                p.pointName = "C" + (j / 5);
                p.licheng = k;
                p.X = M[i].X + j * Math.Cos(fangwei[i]);
                p.Y = M[i].Y + j * Math.Sin(fangwei[i]);
                HDM1.Add(p);
            } else {
                HDM1.Add(M[i]);
            }
            k = k + 5;
        }
        //MessageBox.Show(HDM1[10].X.ToString());
        HDM.Add(HDM1);
        //MessageBox.Show(HDM[0][10].X.ToString());
    }
    for (var i = 0; i < n; i++) //n个横断面
    {
        var d;
        var dianhao = 0;
        for (var j = 0; j < HDM[i].Count; j++) //对每个断面的所有内插点都进行遍历
        {
            var dmin1 = 0;
            var HD = 0,
                LD = 0; //计算插值点高程
            for (var q = 0; q < 5; q++) //寻找最近的5个点
            {
                var dmin = 1000000000000;
                for (var k = 0; k < data.length; k++) //遍历所有散点
                {
                    d = Calculate.Distance(HDM[i][j], point1[k]);
                    if (dmin > d && d > dmin1) {
                        dmin = d;
                        dianhao = k;
                    }
                }
                dmin1 = dmin; //存储最小值，次小值，方便排序
                //MessageBox.Show(dmin.ToString());
                HD = HD + point1[dianhao].Z / dmin;
                LD = LD + 1 / dmin;
            }
            HDM[i][j].Z = HD / LD;
        }
    }
    var S = new double[n];
    for (var i = 0; i < n; i++) //横断面个数 每个循环求每个横断面面积
    {
        for (var j = 0; j < HDM[i].Count - 1; j++) {
            S[i] = S[i] + ((HDM[i][j].Z + HDM[i][j + 1].Z - 2 * gaocheng) * 5 / 2);
        }
    }
}