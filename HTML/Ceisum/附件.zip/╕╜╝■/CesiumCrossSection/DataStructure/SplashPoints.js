//导入的点
function SplashPoints() {
    this.number = 0;

    this.x = 0;
    this.y = 0;
    this.h = 0;
}