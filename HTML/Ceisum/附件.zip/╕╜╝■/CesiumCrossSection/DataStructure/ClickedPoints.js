//选择点
function ClickedPoints() {
    //大地坐标
    this.B = undefined;
    this.L = undefined;
    this.H = undefined;

    //空间直角坐标
    this.X = 0;
    this.Y = 0;
    this.Z = 0;

    //平面投影坐标
    this.x = 0;
    this.y = 0;
    this.h = 0;
}